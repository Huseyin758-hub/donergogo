DönerGo Android — Telefon için proje
Demo admin şifresi: 1234
Bu proje Android Studio/uyumlu Android derleyicilerinde APK'ya çevrilebilir.
Gerçek ödeme, sunucu ve veritabanı henüz eklenmemiştir.
